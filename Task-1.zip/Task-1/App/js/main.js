﻿(function() {
  'use strict';
  var app = WinJS.Application;
  var activation = Windows.ApplicationModel.Activation;
  var count = 0;
  var string;
  var appData = Windows.Storage.ApplicationData.current;
  var rs= appData.roamingSettings;
  app.onactivated = function (args) {
    if (args.detail.kind === activation.ActivationKind.launch) {
      if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
          // TODO: This application has been newly launched. Initialize your application here.
          count = rs.values["count"];
          document.body.style.backgroundColor = rs.values["color"];
          if (!document.body.style.backgroundColor)
              document.body.style.backgroundColor = "violet";
          if (!TextView)
              TextView = 0;
          document.getElementById("counter").innerText = ("Number of Clicks : " + TextView);
      } else {
        // TODO: This application has been reactivated from suspension.
          // Restore application state here.

      }
      args.setPromise(WinJS.UI.processAll().then(function() {
        // TODO: Your code here.
      }));
      var clik = document.getElementById("click");
      clik.addEventListener("click", increase, false);
      clik.addEventListener("click", colorchange, false);
      var res = document.getElementById("clear");
      res.addEventListener("click", resetcounter, false);
      res.addEventListener("click", resetcolor, false);
    }
  };
  app.oncheckpoint = function (args) {
    // TODO: This application is about to be suspended. Save any state that needs to persist across suspensions here.
    // You might use the WinJS.Application.sessionState object, which is automatically saved and restored across suspension.
    // If you need to complete an asynchronous operation before your application is suspended, call args.setPromise().
  };
  function increase(eventInfo) {
      count++;
      string = "NO OF CLICKS =" + count;
      document.getElementById("count").innerText = string;
      rs.values["count"] = count;
  }
  function colorchange(eventInfo) {
      if (document.body.style.backgroundColor == "violet")
          document.body.style.backgroundColor = "red";
      else if (document.body.style.backgroundColor == "red")
          document.body.style.backgroundColor = "greenyellow";
      else if (document.body.style.backgroundColor == "greenyellow")
          document.body.style.backgroundColor = "cadetblue";
      else if (document.body.style.backgroundColor == "cadetblue")
          document.body.style.backgroundColor = "green";
      else if (document.body.style.backgroundColor == "green")
          document.body.style.backgroundColor = "orange";
      else if (document.body.style.backgroundColor == "orange")
          document.body.style.backgroundColor = "blue";
      else if (document.body.style.backgroundColor == "blue")
          document.body.style.backgroundColor = "darkred";
      else if (document.body.style.backgroundColor == "darkred")
          document.body.style.backgroundColor = "fuchsia";
      else if (document.body.style.backgroundColor == "fuchsia")
          document.body.style.backgroundColor = "yellow";
      else if (document.body.style.backgroundColor == "yellow")
          document.body.style.backgroundColor = "deeppink";
      else if (document.body.style.backgroundColor == "deeppink")
          document.body.style.backgroundColor = "white";
      else if (document.body.style.backgroundColor == "white")
          document.body.style.backgroundColor = "violet";
      roamingSettings.values["color"] = document.body.style.backgroundColor;
  }
  function resetcounter(eventInfo) {
      count = 0;
      string = "NO OF CLICKS =" + count;
      document.getElementById("count").innerText = string;
      rs.values["count"] = count;
  }
  function resetcolor(eventInfo) {
      document.body.style.backgroundColor = "violet";
      roamingSettings.values["color"] = document.body.style.backgroundColor;
  }
  app.start();
}());
